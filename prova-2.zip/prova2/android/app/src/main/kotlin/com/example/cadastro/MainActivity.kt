package com.example.cadastro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
