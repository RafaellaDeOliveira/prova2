import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:connectivity/connectivity.dart';
import 'package:prova2/view/utils.dart';
import 'package:overlay_support/overlay_support.dart';
import 'dart:async';

import '../main.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  static final String title = 'Has Internet?';

  @override
  Widget build(BuildContext context) => OverlaySupport(
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: title,
          theme: ThemeData(primarySwatch: Colors.teal),
          home: internetConnection(),
        ),
      );
}

class internetConnection extends StatefulWidget {
  @override
  _internetConnectionState createState() => _internetConnectionState();
}

class _internetConnectionState extends State<internetConnection> {
  late StreamSubscription subscription;

  @override
  void initState() {
    super.initState();

    subscription =
        Connectivity().onConnectivityChanged.listen(showConnectivitySnackBar);
  }

  @override
  void dispose() {
    subscription.cancel();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text("Teste de conexão"),
        ),
        body: Center(
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(padding: EdgeInsets.all(12)),
            child: Text('Testar conexão', style: TextStyle(fontSize: 20)),
            onPressed: () async {
              final result = await Connectivity().checkConnectivity();
              showConnectivitySnackBar(result);
            },
          ),
        ),
      );

  void showConnectivitySnackBar(ConnectivityResult result) {
    final hasInternet = result != ConnectivityResult.none;
    final message = hasInternet
        ? 'You have again ${result.toString()}'
        : 'You have no internet';
    final color = hasInternet ? Colors.green : Colors.red;
    showAlertDialog(context, message, color);
  }

  showAlertDialog(BuildContext context, String message, Color color) {
    // Create button
    Widget okButton = FlatButton(
      child: Text("x"),
      textColor: Colors.white,
      onPressed: () {
        Navigator.of(context).pop();
      },
    );

    // Create AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Informação"),
      titleTextStyle: TextStyle(
          color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
      content: Text(message),
      contentTextStyle: TextStyle(color: Colors.white, fontSize: 18),
      backgroundColor: color,
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
